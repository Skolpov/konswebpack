const Theme = {
  LIGHT: 'light',
  DARK: 'dark'
};

export { Theme };
