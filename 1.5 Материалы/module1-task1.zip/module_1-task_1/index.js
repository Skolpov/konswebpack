import keyHandler from './js/keyHandler.js';
import btnHandler from './js/btnHandler.js';

keyHandler();
btnHandler();
