import './index.scss';
import btnHandler from './js/btnHandler';
import keyHandler from './js/keyHandler';
import {secretBtn} from './js/secretBtn';
keyHandler();
btnHandler();
secretBtn();
