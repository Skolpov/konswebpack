import {secretBtn} from '../js/secretBtn';
import './sup.scss';
secretBtn();
