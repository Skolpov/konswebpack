import keyHandler from '../js/keyHandler';
import './index.scss';
keyHandler();
