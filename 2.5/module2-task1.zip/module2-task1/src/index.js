import btnHandler from './js/btnHandler';
import keyHandler from './js/keyHandler';

keyHandler();
btnHandler();
